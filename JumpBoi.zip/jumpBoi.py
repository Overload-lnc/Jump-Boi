import pygame
import random


def createWindow(width, length, title, has_icon, icon_path):
    window = pygame.display.set_mode((width, length))
    pygame.display.set_caption(title)
    if has_icon:
        pygame.display.set_icon(load_img(icon_path))
    return window


class Clock:
    def __init__(self, tick_speed):
        self.speed = tick_speed
        self.clock = pygame.time.Clock()

    def tick(self):
        self.clock.tick(self.speed)

    def tickDifferent(self, new_speed):
        self.clock.tick(new_speed)


def load_img(img_dir):
    return pygame.image.load(img_dir)


def x_checker(start, end, current_x):
    '''
    returns true if current_x is between start and end
    '''

    if start <= current_x <= end:
        return True
    else:
        return False


def y_checker(start, end, current_y):
    '''
        returns true if current_y is between start and end
    '''
    if start <= current_y <= end:
        return True
    else:
        return False


def message_dur(msg, screen, bg_color, msg_color, loc, font_size, duration):
    '''
    writes a message on the whole screen
    you can only use it at either start or end
    it doesn't work in fill()-display() part
    '''
    message_font = pygame.font.SysFont("Arial", font_size)
    message_text = message_font.render(msg, False, msg_color)
    for i in range(duration):
        screen.fill(bg_color)
        screen.blit(message_text, loc)
        pygame.display.update()


def writeText(window, loc, text):
    window.blit(text, loc)


class Color:
    def __init__(self, r, g, b):
        self.r = r
        self.g = g
        self.b = b

    def color(self):
        return self.r, self.g, self.b


class Character:
    def __init__(self, x, y, width, length, key_map, window):
        self.width = width
        self.length = length

        self.x = x
        self.y = y
        self.max_x = 1000000 - self.width
        self.min_x = 0
        self.max_y = 1000000 - self.length
        self.min_y = 0

        self.window = window
        self.death = False
        self.respawnX = x
        self.respawnY = y

        self.key_binds = {
            "w": pygame.K_w, "a": pygame.K_a, "s": pygame.K_s, "d": pygame.K_d, "e": pygame.K_e,
            "q": pygame.K_q, "f": pygame.K_f, "r": pygame.K_r, "z": pygame.K_z, "x": pygame.K_x,
            "c": pygame.K_c, "v": pygame.K_v, "t": pygame.K_t, "g": pygame.K_g, "b": pygame.K_b,
            "y": pygame.K_y, "h": pygame.K_h, "n": pygame.K_n, "u": pygame.K_u, "j": pygame.K_j,
            "m": pygame.K_m, "k": pygame.K_k, "o": pygame.K_o, "l": pygame.K_l, "p": pygame.K_p,
            "up": pygame.K_UP, "down": pygame.K_DOWN, "left": pygame.K_LEFT, "right": pygame.K_RIGHT
        }

        if key_map[0] != "":
            self.ver_pos = self.key_binds[key_map[0]]
        else:
            self.ver_pos = ""
        if key_map[1] != "":
            self.ver_neg = self.key_binds[key_map[1]]
        else:
            self.ver_neg = ""
        if key_map[2] != "":
            self.hor_pos = self.key_binds[key_map[2]]
        else:
            self.hor_pos = ""
        if key_map[3] != "":
            self.hor_neg = self.key_binds[key_map[3]]
        else:
            self.hor_neg = ""

    def hitbox(self, trigger_x, trigger_y):
        return RectHitbox(self.x, self.y, self.x + self.width, self.y + self.length).detect(trigger_x, trigger_y)

    def respawn(self):
        self.death = False
        self.x = self.respawnX
        self.y = self.respawnY

    def drawRect(self, color, thickness, look_death):
        if look_death is True:
            if self.death is False:
                pygame.draw.rect(self.window, color, (self.x, self.y, self.width, self.length), thickness)
        else:
            pygame.draw.rect(self.window, color, (self.x, self.y, self.width, self.length), thickness)

    def drawCircle(self, color, width, radius, look_death):
        if look_death is True:
            if self.death is False:
                pygame.draw.circle(self.window, color, (self.x, self.y), radius, width)
        else:
            pygame.draw.circle(self.window, color, (self.x, self.y), radius, width)

    def drawTexture(self, img, look_death):
        if look_death is True:
            if self.death is False:
                self.window.blit(img, (self.x, self.y))
        else:
            self.window.blit(img, (self.x, self.y))

    def centerPoint(self):
        return self.x + self.width / 2, self.y + self.length / 2

    def centerX(self):
        return self.x + self.width / 2

    def centerY(self):
        return self.y + self.length / 2

    def clamp(self):
        if self.x < self.min_x:
            self.x = self.min_x
        elif self.x > self.max_x:
            self.x = self.max_x

        if self.y < self.min_y:
            self.y = self.min_y
        elif self.y > self.max_y:
            self.y = self.max_y

    def setXLimit(self, min, max):
        self.max_x = max - self.width
        self.min_x = min

    def setYLimit(self, min, max):
        self.max_y = max - self.length
        self.min_y = min


class RectHitbox:
    def __init__(self, start_x, end_x, start_y, end_y):
        self.start_x = start_x
        self.end_x = end_x
        self.start_y = start_y
        self.end_y = end_y

    def draw(self, thickness, screen):
        pygame.draw.rect(screen, (255, 255, 255), (self.start_x, self.start_y,
                                                   (self.end_x - self.start_x),
                                                   (self.end_y - self.start_y)), thickness)

    def drawTex(self, window, img):
        window.blit(img, (self.start_x, self.start_y))

    def detect(self, target_x, target_y):
        if x_checker(self.start_x, self.end_x, target_x) and y_checker(self.start_y, self.end_y, target_y):
            return True
        else:
            return False

    def reval(self, x, x2, y, y2, mode):
        if mode == 0:
            self.start_x = x
            self.end_x = x2
            self.start_y = y
            self.end_y = y2
        if mode == 1:
            self.start_x += x
            self.end_x += x2
            self.start_y += y
            self.end_y += y2


class Counter:
    def __init__(self, limit):
        self.limit = limit
        self.count = 0
        self.cycle = 0

    def count_up(self, by):
        self.count += by

    def check(self):
        if self.count >= self.limit:
            self.count = 0
            self.cycle += 1
            return True

    def auto_check(self, by):
        if self.count >= self.limit:
            self.count = 0
            self.cycle += 1
            return True
        else:
            self.count += by


def fontCreator(font_name, size):
    return pygame.font.SysFont(font_name, size)


def textRenderer(font, text, color):
    return font.render(text, False, color)


# basic initialization
pygame.init()
window = createWindow(600, 177, "Jump Boi", False, "")
clock = Clock(90)
run = True

black = Color(0, 0, 0).color()
white = Color(255, 255, 255).color()
green = Color(0, 255, 0).color()
red = Color(255, 0, 0).color()

tex_jump = load_img("BoiJump.png")
tex_crouch = load_img("BoiCrouch.png")
tex_crouch2 = load_img("BoiCrouch2.png")
tex_left = load_img("BoiLeft.png")
tex_right = load_img("BoiRight.png")
cactit1 = load_img("cacti1.png")
cactit2 = load_img("cacti2.png")
current = tex_left

dino = Character(5, 100, 23, 42, ["w", "s", "", ""], window)
speed = 2
jump = 100
jump_speed = 3
jump_count = 0
jmp = False
top = False
crouch = 11
crch = False
score = 0
auto_jump = False

min_dis = 110
max_dis = 230
cacti_width = 23
cacti_height = 46
cacti1_x = random.randint(610, 670)
cacti1 = RectHitbox(cacti1_x, cacti1_x + cacti_width, 97, 97 + cacti_height)
cacti1_x = random.randint(min_dis, max_dis)
cacti2 = RectHitbox(cacti1.start_x + cacti1_x, cacti1.end_x + cacti1_x, 97, 97 + cacti_height)
cacti1_x = random.randint(min_dis, max_dis)
cacti3 = RectHitbox(cacti2.start_x + cacti1_x, cacti2.end_x + cacti1_x, 97, 97 + cacti_height)

counter = Counter(20)

main_font = fontCreator("Arial", 15)

message_dur("Game by Overload Inc.", window, black, white, (200, 80), 20, 9000)
message_dur("\'Inspired\' from Google\'s Dino Game", window, black, white, (170, 80), 20, 10000)

while run:
    # reval zone
    if cacti1.start_x < -23:
        cacti1_x = random.randint(610, 670)
        cacti1.reval(cacti1_x, cacti1_x + cacti_width, 97, 97 + cacti_height, 0)
    if cacti2.start_x < -23:
        cacti1_x = random.randint(min_dis, max_dis)
        cacti2.reval(cacti1.start_x + cacti1_x, cacti1.end_x + cacti1_x, 97, 97 + cacti_height, 0)
    if cacti3.start_x < -23:
        cacti1_x = random.randint(min_dis, max_dis)
        cacti3.reval(cacti2.start_x + cacti1_x, cacti2.end_x + cacti1_x, 97, 97 + cacti_height, 0)
    if 40 < score < 41:
        jump_speed = 3.5
        speed = 2.4
    if 80 < score < 81:
        jump_speed = 3.8
        speed = 2.6
    if 100 < score < 101:
        jump_speed = 4
        speed = 2.9
    cacti1.reval(-1 * speed, -1 * speed, 0, 0, 1)
    cacti2.reval(-1 * speed, -1 * speed, 0, 0, 1)
    cacti3.reval(-1 * speed, -1 * speed, 0, 0, 1)
    t1 = textRenderer(main_font, "Score: %.0f" % score, white)

    # event handler
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

        if event.type == pygame.KEYDOWN:

            if event.key == pygame.K_ESCAPE:
                run = False

            if event.key == dino.ver_pos:
                auto_jump = True
            if event.key == dino.ver_neg and crch is False:
                crch = True
                dino.length -= crouch
                dino.y += crouch

        if event.type == pygame.KEYUP:
            if event.key == dino.ver_neg and crch is True:
                crch = False
                dino.length += crouch
                dino.y -= crouch
            if event.key == dino.ver_pos:
                auto_jump = False

    if auto_jump and jmp is False:
        jmp = True
    if jmp:
        if jump_count < jump and top is False:
            jump_count += jump_speed
            dino.y -= jump_speed
            if jump_count >= jump:
                top = True
    if top:
        if jump_count > 0:
            jump_count -= jump_speed
            dino.y += jump_speed
            if jump_count <= 0:
                jmp = False
                top = False

    window.fill(black)
    # graphics stuff here
    pygame.draw.line(window, white, (0, 143), (599, 143), 1)
    cacti1.drawTex(window, cactit1)
    cacti2.drawTex(window, cactit2)
    cacti3.drawTex(window, cactit1)
    if jmp:
        current = tex_jump
    elif crch:
        if counter.auto_check(1):
            if counter.cycle % 2 == 0:
                current = tex_crouch
            else:
                current = tex_crouch2
    else:
        if counter.auto_check(1):
            if counter.cycle % 2 == 0:
                current = tex_right
            else:
                current = tex_left
    dino.drawTexture(current, False)

    if cacti1.detect(dino.centerX(), dino.centerY()) or \
        cacti2.detect(dino.centerX(), dino.centerY()) or \
        cacti3.detect(dino.centerX(), dino.centerY()):
        run = False

    score += 1 / 90

    writeText(window, (15, 150), t1)

    pygame.display.update()
    clock.tick()
message_dur("SCORE: %.0f" % score, window, black, red, (240, 80), 20, 9000)
pygame.quit()
